import NeonIsometricMaze from "../neon-isometric-maze"

export default function Home() {
  return (
    <main className="w-full h-screen overflow-hidden bg-white">
      <NeonIsometricMaze />
    </main>
  )
}
